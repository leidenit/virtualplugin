<?php
//Vm module initialization
include_once "lib/functions.php";
include_once "modules/virtualboxscript/functions.php";
?>