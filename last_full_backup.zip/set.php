<!-- Page: settings(настройки) -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="header">
                        <h4 class="title"> Настройки</h4>
                    </div>
                    <div class="content">
                        <div class="row">
                            <div class="col-md-12">
                                Вы не можете ничего настраивать
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>