<!-- All pages footer-->
</div>
</div>
</body>
<!--   Core JS Files   -->
<script src="<?=$main_host?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<!--  Checkbox, Radio & Switch Plugins -->
<script src="<?=$main_host?>assets/js/bootstrap-checkbox-radio-switch.js"></script>
<!--  Charts Plugin
<script src="/virtualplugin/assets/js/chartist.min.js"></script>-->
<!--  Notifications Plugin    -->
<script src="<?=$main_host?>assets/js/bootstrap-notify.js"></script>
<!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
<script src="<?=$main_host?>assets/js/light-bootstrap-dashboard.js"></script>
<!--  Listgroup Plugin -->
<script src="<?=$main_host?>assets/js/listgroup.js"></script>
</html>
