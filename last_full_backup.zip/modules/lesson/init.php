<?php
//Lesson module initialization
include_once "lib/functions.php";
include_once "modules/vm/lib/functions.php"
?>