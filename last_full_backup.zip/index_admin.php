<?php
?>






<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="content">
                    Вы вошли как администратор</br>

                    Вам доступны разделы:
                    <ul>
                        <li>Пользователь</li>
                        <li>Шаблоны ВС</li>
                        <li>Шаблоны ВМ</li>
                    </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

