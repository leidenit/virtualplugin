<?php
require_once "libs/db/db_functions.php";
EXPORT_TABLES($db_host,$db_user,$db_pass,$db_database,false, false);
?>

