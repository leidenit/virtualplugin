<!-- Page: error(ошибка) -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Упс. Кажется вы ошиблись!</h4>
                    </div>
                    <div class="content">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script></script>